-- https://github.com/riddle206/riddle_protect/

local old = http.Fetch
local blacklist = {
    "kvac",
    "kvcdoor",
    "kvc",
}
http.Fetch = function( url, onsucess, onfailire, headers )
    local a
    for i=1, #blacklist do
        a = string.find( string.lower(url), blacklist[i] )
    end

    if a then 
        local source = debug.getinfo(2)
        print("Backdoor Trouvé ! >>", url, source.short_src)
        return 
    end

    return old( url, onsucess, onfailire, headers )
end