Salut toi ! Si tu es la c'est que tu veux prendre des mésures pour protéger ton serveur contre les backdoor

J'ai fais ce simple code qui bloque kvac (pour l'instant) mais je l'améliorais à l'avenir si d'autres panel existe ! Je rapelles que le but de ce code est de se protéger contre vos développeurs qui tenterais de niqué votre serveur sans scrupules.

Pour l'installer, installer riddle_protect et glisser le simplement dans garrysmod/addons